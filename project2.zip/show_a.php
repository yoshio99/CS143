<!DOCTYPE html>
<html>
<title>
Show Actress Info
</title>
<h1>
Information on Julia Roberts
</h1>
<br>
<h2>
<a href="index.php">Go to Home Page</a>
</h2>
<div class = "col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
<hr>
<?php
$db = new mysqli('localhost', 'cs143', '', 'cs143');
if ($db->connect_errno > 0) {
	die('Unable to connect to database [' . $db->connect_error . ']');
}
$query = "SELECT first,last,sex,dob,dod FROM Actor WHERE first = 'Julia' AND last = 'Roberts'";
$rs = $db->query($query);
while($row = $rs->fetch_assoc()) {
	$data[] = $row;
}
$rs->free();
$col_names = array_keys(reset($data));
echo "<h3> Actor Information: </h3>";
echo "<table border = '1'>";
echo "<tr>";
foreach($col_names as $col_name) {
	echo "<th>$col_name</th>";
}
echo "</tr>";
foreach($data as $row) {
	echo "<tr>";
	foreach($col_names as $col_name) {
		echo "<td>".$row[$col_name]."</td>";
	}
}
echo "</table>";
$query = "SELECT role, title FROM Actor as a, MovieActor as ma, Movie as m WHERE first = 'Julia' AND last = 'Roberts' AND a.id = aid AND mid = m.id";
$rs = $db->query($query);
while($row = $rs->fetch_assoc()) {
	$roles[] = $row;
}
$rs->free();
$col_names = array_keys(reset($roles));
echo "<h3> Actor's Movies and Roles </h3>";
echo "<table border = '1'>";
echo "<tr>";
foreach($col_names as $col_name) {
	echo "<th>$col_name</th>";
}
echo "</tr>";
foreach($roles as $row) {
	echo "<tr>";
	foreach($col_names as $col_name) {
		echo "<td>".$row[$col_name]."</td>";
	}
}
echo "</table>";
$db->close();
?>


</html>
