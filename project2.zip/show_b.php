<!DOCTYPE html>
<html>
<title>
Show Movie Info
</title>
<h1>
Information on The Matrix
</h1>
<br>
<h2>
<a href="index.php">Go to Home Page</a>
</h2>
<br>
<h2>
<a href="show_a.php">Go to Actress Page</a>
</h2>
<div class = "col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
<hr>
<?php
$db = new mysqli('localhost', 'cs143', '', 'cs143');
if($db->connect_errno > 0) {
	die('Unable to connect to database [' . $db->connect_error . ']');
}
$query = "SELECT title,year,rating,company FROM Movie WHERE title = 'Matrix, The'";
$rs = $db->query($query);
while($row = $rs->fetch_assoc()) {
	$data[] = $row;
}
$rs->free();
$col_names = array_keys(reset($data));
echo "<h3> Movie Information </h3>";
echo "<table border = '1'>";
echo "<tr>";
foreach($col_names as $col_name) {
	echo "<th>$col_name</th>";
}
echo "</tr>";
foreach($data as $row) {
	echo "<tr>";
	foreach($col_names as $col_name) {
		echo "<td>".$row[$col_name]."</td>";
	}
}
echo "</table>";
$query = "SELECT first,last,role FROM Movie as m, MovieActor as ma, Actor as a WHERE title = 'Matrix, The' AND m.id = mid AND aid = a.id";
$rs = $db->query($query);
while($row = $rs->fetch_assoc()) {
	$actors[] = $row;
}
$rs->free();
$col_names = array_keys(reset($actors));
echo "<h3> Actors in The Matrix </h3>";
echo "<table border = '1'>";
echo "<tr>";
foreach($col_names as $col_name) {
	echo "<th>$col_name</th>";
}
echo "</tr>";
foreach($actors as $row) {
	echo "<tr>";
	foreach($col_names as $col_name) {
		echo "<td>".$row[$col_name]."</td>";
	}
}
echo "</table>";
$query = "SELECT COUNT(r.rating) as rating_count, AVG(r.rating) as rating_avg FROM Movie as m, Review as r WHERE title = 'Matrix, The' AND id = mid";
$rs = $db->query($query);
echo "<h3> User Review: </h3>";
if(!$rs) {
	$errmsg = $db->error;
	print "There are no reviews for this movie: $errmsg <br>";
}
else {
	while($row = $rs->fetch_assoc()) {
		$rating_count = $row['rating_count'];
		$rating_avg = $row['rating_avg'];
	}
	echo "Average score for this movie is $rating_avg/5 based on $rating_count reviews.";
	$rs->free();
}
echo "<br>";
echo "<h3> User Comments: </h3>";
$query = "SELECT comment FROM Movie as m, Review as r WHERE title = 'Matrix, The' AND id = mid";
$rt = $db->query($query);
if(!$rt) {
	$errmsg = $db->error;
	print "There are no comments for this movie. <br>";
	exit(1);
}
else {
	while($row = $rt->fetch_assoc()) {
		$comments[] = $row;
	}
	$rt->free();
	$col_names = array_keys(reset($comments));
	echo "<table border = '1'>";
	echo "<tr>";
	foreach($col_names as $col_name) {
		echo "<th>$col_name</th>";
	}
	echo "</tr>";
	foreach($comments as $row) {
		echo "<tr>";
		foreach($col_names as $col_name) {
			echo "<td>".$row[$col_name]."</td>";
		}
	}
	echo "</table>";
}
$db->close();
?>
</html>
