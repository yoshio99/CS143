<!DOCTYPE html>
<html>
<title>
Adding New Comment
</title>
<h1>
Add a New Comment for The Matrix!
</h1>
<br>
<h2>
<a href="index.php">Go to Home Page</a>
</h2>
<div class = "col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
<hr>
<label for="name_input">Your Name:</label>
<br>
<form method="POST" action="give_review.php">
<input type="text" placeholder="Type username here..." name="name" required>
<br>
<label for="rating_input">Rate the movie:</label>
<select name="rating" placeholder="Select rating here...">
	<option>1</option>
	<option>2</option>
	<option>3</option>
	<option>4</option>
	<option>5</option>
</select>
<br>
<textarea name="comment" rows="5" cols="30" placeholder="Add comment here...">
</textarea>
<br>
<input type="submit" name="submit" value="Submit Rating" class="btn btn-default" style="margin-bottom:10px">
</form>
<?php
if(isset($_POST['name']) && isset($_POST['comment']) && isset($_POST['submit'])) {
	$db = new mysqli('localhost','cs143','','cs143');
	if($db->connect_errno > 0) {
		die('Unable to connect to database [' . $db->connect_error . ']');
	}
	$name = $_POST['name'];
	$comment = $_POST['comment'];
	$rating = (int)$_POST['rating'];
	$id = (int)"2632";
	$date = date("Y-m-d H:i:s");
	$query = "INSERT INTO Review (name, time, mid, rating, comment) VALUES ('$name', '$date', '$id', '$rating', '$comment')";
	$rs = $db->query($query);
	if(!$rs) {
		$errmsg = $db->error;
		print "The query was not submitted: $errmsg <br>";
	}
	$rs->free();
	$db->close();
}
?>
</html>
