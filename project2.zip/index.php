<!DOCTYPE hyml>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CS143 MySQL-Apache Container</title>
</head>
<body>
<h1>CS 143 Project 2</h1>
<h2>Tyler Adair</h2> 
<p><a href="search.php">Search Actor/Movie</a></p>
<br>
<p><a href="show_a.php">Show Actress Julia Roberts</a></p>
<br>
<p><a href="show_b.php">Show Movie: The Matrix</a></p>
<br>
<p><a href="give_review.php">Give a Review for The Matrix</a></p>
</body>
</html>
