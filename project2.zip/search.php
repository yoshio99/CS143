<!DOCTYPE html>
<html>
<title>
Search page for Project 2
</title>
<h1>
Search Page
</h1>
<br>
<h2>
<a href="index.php">Go to Home Page</a>
</h2>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
<hr>
<label for="search_input">Search for an Actor/Movie:</label>
<form METHOD="POST" ACTION="search.php">
<input type="text" placeholder="Type search here..." name="result" required>
<br>
<input type="submit" name="submit" value="Enter" class="btn btn-default" style="margin-bottom:10px">
</form>
<?php
if(isset($_POST['submit']) && isset($_POST['result'])) {
	$db = new mysqli('localhost', 'cs143','','cs143');
	if ($db->connect_errno > 0) {
		die('Unable to connect to database [' . $db->connect_error . ']');
	}
	$parts = explode(" ",$_POST['result']);
	$clauses_actors = array();
	$clauses_movies = array();
	foreach ($parts as $part) {
		$clauses_actors[] = "SELECT first,last,dob FROM Actor WHERE first LIKE '%" . $db->real_escape_string($part) . "%' OR last LIKE '%" . $db->real_escape_string($part) . "%'";
		$clauses_movies[] = "SELECT title, year FROM Movie WHERE title LIKE '%" . $db->real_escape_string($part) . "%'";
	}
	$query_actors = implode(" INTERSECT ", $clauses_actors);
	$query_movies = implode(" INTERSECT ", $clauses_movies);
	$rs = $db->query($query_actors);
	while($row = $rs->fetch_assoc()) {
		//echo $row['first'] . ", " ;
		//echo $row['last'] . ", " ;
		//echo $row['dob'] . "<br>";
		$data[] = $row;
	}
	$rs->free();
	$col_names = array_keys(reset($data));
	echo "<h3> Matching Actors: </h3>";
	echo "<table border = '1'>";
	echo "<tr>";
	foreach($col_names as $col_name) {
		echo "<th>$col_name</th>";
	}
	echo "</tr>";
	foreach($data as $row) {
		echo "<tr>";
		foreach($col_names as $col_name) {
			echo "<td>".$row[$col_name]."</td>";
		}
		echo "</tr>";
	}
	echo "</table>";
	$rs = $db->query($query_movies);
	while($row = $rs->fetch_assoc()) {
		$movies[] = $row;
	}
	$col_names = array_keys(reset($movies));
	echo "<h3> Matching Movies: </h3>";
	echo "<table border = '1'>";
	echo "<tr>";
	foreach($col_names as $col_name) {
		echo "<th>$col_name</th>";
	}
	echo "</tr>";
	foreach($movies as $row) {
		echo "<tr>";
		foreach($col_names as $col_name) {
			echo "<td>".$row[$col_name]."</td>";
		}
		echo "</tr>";
	}
	echo "</table>";
	$rs->free();
	$db->close();
}
?>
</div>
</html>
